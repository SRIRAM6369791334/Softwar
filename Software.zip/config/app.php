<?php

return [
    'app_name' => 'Supermarket OS',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
];
